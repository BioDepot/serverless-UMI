#lhhung 013119 - refactored and extended Dimitar Kumar's original script

from subprocess import call
from pathlib import Path
import sys
import glob
import stat
import os
import boto3
import botocore
import time
import datetime
import json

# A utility function to run a bash command from python
def runCmd(cmd):
    sys.stderr.write("#{}\n".format(cmd))
    call([cmd], shell=True)

#utilities to remove directories and files except those in the whitelist
def removeDirectoriesExcept(rootDirectory,whiteList):
    for directory in os.popen('find {} -type d -mindepth 1 -maxdepth 1 '.format(rootDirectory)).read().split('\n')[0:-1]:
        if directory not in whiteList:
            sys.stderr.write("removing {}\n".format(directory))
            runCmd("rm {} -rf".format(directory))
            
def removeFilesExcept(rootDirectory,whiteList):
    for myFile in os.popen('find {} -type f '.format(rootDirectory)).read().split('\n')[0:-1]:
        if myFile not in whiteList:
            sys.stderr.write("removing {}\n".format(myFile))
            try:
                os.remove(myFile)
            except Exception as e:
                sys.stderr.write('unable to remove {}\n'.format(myFile))
                

def downloadFiles(sourceFile,destFile,bucketName,overwrite=True,verbose=True):
    sourceFile=sourceFile.replace("/home/ubuntu/LINCS/","")
    s3 = boto3.resource('s3')
    if overwrite or not os.path.exists(destFile):
        try:
            if verbose:
                sys.stderr.write("Downloading {} to {}\n".format(sourceFile,destFile))
                s3.Bucket(bucketName).download_file(sourceFile, destFile)
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                sys.stderr.write("The object does not exist\n")
            else:
                raise
            
# Performs BWA for the given splitFile, filterCmd, and outputFile
def runBwa(splitFile,outputFile,filterCmd,bwa_string):
    cmdStr="/tmp/{} /tmp/refMrna_ERCC_polyAstrip.hg19.fa /tmp/{} | /tmp/bwa samse -n 20 /tmp/refMrna_ERCC_polyAstrip.hg19.fa - /tmp/{} | {} > {} ".format(bwa_string,splitFile,splitFile,filterCmd,outputFile)
    sys.stderr.write("running cmd:\n{}\n".format(cmdStr))
    runCmd(cmdStr)

def uploadResultsTest(sourceFile,destFile,bucketName):
    sys.stderr.write("cp {} {}\n".format(sourceFile,destFile))
# Uploads the result to the appropriate S3 Aligns/splitFile folder
def uploadResults(sourceFile,destFile,bucketName):
    s3 = boto3.resource('s3')
    destFile=destFile.replace("/home/ubuntu/LINCS/Aligns","Outputs")
    return s3.meta.client.upload_file(sourceFile, bucketName,destFile)

# Lambda's entry point.
def lambda_handler(event, context):
    #default bwa command
    bwa_string='bwa aln -l 24 -t 2 '
    #json payload   
    fullPathSplitFile=event['Records'][0]['Sns']['MessageAttributes']['splitFile']['Value']
    topicArn=event['Records'][0]['Sns']['MessageAttributes']['topicArn']['Value']
    bucketName=event['Records'][0]['Sns']['MessageAttributes']['bucketName']['Value']
    baseDirectory=event['Records'][0]['Sns']['MessageAttributes']['baseDirectory']['Value']
    uploadDir=event['Records'][0]['Sns']['MessageAttributes']['uploadDir']['Value']
    if 'bwa_string' in event['Records'][0]['Sns']['MessageAttributes']:
        bwa_string=event['Records'][0]['Sns']['MessageAttributes']['bwa_string']['Value']
    
    #publish start message and send start file
    publisher=boto3.client('sns')
    Path('/tmp/start').touch()
    splitFile=os.path.basename(fullPathSplitFile)
    uploadResults('/tmp/start',os.path.join(os.path.join(baseDirectory,"start"),splitFile),bucketName)
    publisher.publish(TopicArn=topicArn,Message='Start',MessageAttributes={'filename':{'DataType':'String','StringValue':fullPathSplitFile}})
    try:
        #### List of parameters to customize ####
    
        #bwa doesn't actually need the sequence information - just the name to figure out where the indices are
        #these files are empty to save space - probably should add the chrM.fa file 
    
        fakeFiles=['/tmp/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa']
    
        #sourceFiles and directories used in other places
        alignDir='/tmp/Aligns'
        refDir='/tmp/Human_RefSeq'
        barcodeFile="/tmp/barcodes_trugrade_96_set4.dat" #in References/BroadUMI directory
        erccFile="/tmp/ERCC92.fa"
        symToRefFile="/tmp/refGene.hg19.sym2ref.dat"

        #get splitFile from json payload - may want to load s3 bucket from here also instead of hardcoding
 
        splitFile=os.path.basename(fullPathSplitFile)
    
        sourceFiles= [baseDirectory+"/executables/umimerge_filter", 
                  baseDirectory+"/executables/bwa", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/chrM.fa", 
                  baseDirectory+"/References/Broad_UMI/barcodes_trugrade_96_set4.dat",
                  baseDirectory+"/References/Broad_UMI/ERCC92.fa" ,
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refGene.hg19.sym2ref.dat", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refGene.hg19.txt", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.amb", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.ann", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.bwt", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.fai", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.pac", 
                  baseDirectory+"/References/Broad_UMI/Human_RefSeq/refMrna_ERCC_polyAstrip.hg19.fa.sa"]

        #### End parameters list ####

        for sourceFile in sourceFiles:
            sourceFile=baseDirectory+"/"+sourceFile
    
        sys.stderr.write("Running handler for splitFile [{}] at time {}\n"
            .format(
                splitFile,
                datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
            )
        )

        sys.stderr.write("Json dump:\n{}\n".format(json.dumps(event, indent=4, sort_keys=True)))
    
        #cleanup files - keep RefSeq and binaries if already there
        whiteListFiles=[]
        for sourceFile in sourceFiles:
            basesourceFile=os.path.basename(sourceFile)
            destFile='/tmp/'+basesourceFile
            whiteListFiles.append(destFile)
        whiteListFiles=whiteListFiles + fakeFiles
    
        removeDirectoriesExcept('/tmp',['/tmp/Human_RefSeq'])
        removeFilesExcept('/tmp',whiteListFiles)

        #create directories
        for directory in [alignDir,refDir]:
            runCmd('mkdir -p {}'.format(directory))
    
        #make empty fakeFiles
        for fakeFile in fakeFiles:
            if not os.path.exists(fakeFile):
                runCmd('touch {}'.format(fakeFile))
    
        #download source files
        for sourceFile in sourceFiles:
            basesourceFile=os.path.basename(sourceFile)
            destFile='/tmp/'+basesourceFile
            downloadFiles(sourceFile,destFile,bucketName,overwrite=False,verbose=True)

        #download splitFile 
        downloadFiles(fullPathSplitFile,'/tmp/' + splitFile, bucketName,overwrite=True,verbose=True)
    except:
        publisher.publish(TopicArn=topicArn,Message='Error:Download',MessageAttributes={'filename':{'DataType':'String','StringValue':fullPathSplitFile}})
        return
    try:
        #make sure that executables have correct permissions
        for executable in ('/tmp/bwa','/tmp/umimerge_filter'):
            runCmd('chmod +x {}'.format(executable))
        #run bwa 
        outputFile='{}/{}.saf'.format(alignDir,os.path.splitext(splitFile)[0])
        filterCmd="/tmp/umimerge_filter -s {} -b {} -e {}".format(symToRefFile,barcodeFile,erccFile)
        #filterCmd="grep -v '^\@'"
        sys.stderr.write("Starting bwa at {}".format(datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')))
        runBwa(splitFile,outputFile,filterCmd,bwa_string)
    except:
        publisher.publish(TopicArn=topicArn,Message='Error:Align',MessageAttributes={'filename':{'DataType':'String','StringValue':fullPathSplitFile}})
        return

    #upload results
    #uploadFile=os.path.dirname(fullPathSplitFile)+'/'+os.path.basename(outputFile)
    try:
        uploadFile=uploadDir+'/'+os.path.basename(outputFile)
        sys.stderr.write("Starting bwa at {}".format(datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')))
        uploadResults(outputFile,uploadFile,bucketName)
        #uploadResultsTest(outputFile,uploadFile,bucketName)
        #write done time
        sys.stderr.write("Finished at {}".format(datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')))
        publisher.publish(TopicArn=topicArn,Message='Finish',MessageAttributes={'filename':{'DataType':'String','StringValue':fullPathSplitFile}})
    except:
        publisher.publish(TopicArn=topicArn,Message='Error:Upload',MessageAttributes={'filename':{'DataType':'String','StringValue':fullPathSplitFile}})
       
